"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.contrib import admin
from django.conf.urls.static import static
from django.urls import path,include
from news.views import *
from user_account.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('news.urls')),
    path('user_account/',include('user_account.urls')),
    path('institutions/',include('institutions.urls')),
    path('classes/',include('classes.urls')),
    path('journal/',include('journal.urls')),
    path('reports/',include('reports.urls')),
    
]
if settings.DEBUG:
	urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
